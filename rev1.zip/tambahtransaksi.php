<!DOCTYPE html>
<?php
// ======================================================
// (A) INCLUDE KONFIG & CEK LOGIN
// ======================================================
include "include/config.php";
include "include/guard.php";

// ======================================================
// (B) AMBIL DATA MASTER (lokasi, produk, supplier)
// ======================================================
$resultLokasi   = mysqli_query($connection, "SELECT location_id, namalokasi FROM location WHERE status=1 ORDER BY namalokasi");
$resultProduk   = mysqli_query($connection,  "SELECT 
  p.product_id, 
  b.brand_name, 
  m.model_name
FROM product p
LEFT JOIN brand b ON p.brand_id = b.brand_id
LEFT JOIN model m ON p.model_id = m.model_id
WHERE p.status = 1
ORDER BY b.brand_name, m.model_name
");
$resultSupplier = mysqli_query($connection, "SELECT supplier_id, namasupplier FROM supplier WHERE status=1 ORDER BY namasupplier");

// ======================================================
// (C) PROSES SIMPAN TRANSAKSI
//    - tipe: IN / OUT / ADJUST
//    - multi-produk
//    - update inventory (sekaligus quantity_before / quantity_after di detail)
//    - khusus tipe IN => insert ke transaction_stok_in (supplier_id + invoice)
// ======================================================
if (isset($_POST['btnSimpan'])) {
    // ---------- Ambil input utama ----------
    $idLokasi       = (int)($_POST['location_id'] ?? 0);
    $tipeTransaksi  = $_POST['type'] ?? 'IN'; // IN/OUT/ADJUST
    $tanggalTrans   = mysqli_real_escape_string($connection, $_POST['transaction_date'] ?? date('Y-m-d\TH:i'));
    $catatan        = mysqli_real_escape_string($connection, $_POST['note'] ?? '');

    // Validasi lokasi & baris produk
    if ($idLokasi <= 0) {
        die("Lokasi wajib dipilih.");
    }
    $listProdukId = $_POST['product_id'] ?? [];
    $listQtyInput = $_POST['qty'] ?? [];

    if (empty($listProdukId)) {
        die("Minimal satu produk harus diinput.");
    }

    // Khusus tipe IN: ambil supplier & invoice
    $idSupplier = null;
    $noInvoice  = null;
    if ($tipeTransaksi === 'IN') {
        $idSupplier = (int)($_POST['supplier_id'] ?? 0);
        $noInvoice  = mysqli_real_escape_string($connection, $_POST['invoice'] ?? '');
        if ($idSupplier <= 0) {
            die("Supplier wajib dipilih untuk transaksi IN.");
        }
    }

    // ---------- Mulai transaksi DB (atomic) ----------
    mysqli_begin_transaction($connection);
    try {
        // (C1) Insert ke tabel transaction
        $idUserAktif = (int)($_SESSION['user_id'] ?? 1); // sesuaikan: simpan user_id saat login
        $sqlTrans = "
          INSERT INTO `transaction` (location_id, user_id, transaction_date, note, `type`)
          VALUES ($idLokasi, $idUserAktif, '$tanggalTrans', '$catatan', '".mysqli_real_escape_string($connection,$tipeTransaksi)."')
        ";
        mysqli_query($connection, $sqlTrans) or throw new Exception(mysqli_error($connection));
        $idTransaksiBaru = mysqli_insert_id($connection);

        // (C2) Khusus tipe IN => simpan ke transaction_stok_in
        if ($tipeTransaksi === 'IN') {
            $sqlIn = "
              INSERT INTO transaction_stok_in (transaction_id, supplier_id, invoice)
              VALUES ($idTransaksiBaru, $idSupplier, '$noInvoice')
            ";
            mysqli_query($connection, $sqlIn) or throw new Exception(mysqli_error($connection));
        }

        // (C3) Loop tiap baris detail produk
        foreach ($listProdukId as $i => $pidRaw) {
            $idProduk = (int)$pidRaw;
            // qtyInput: 
            // - IN  => dianggap jumlah masuk (positif)
            // - OUT => dianggap jumlah keluar (positif di form, tapi disimpan sebagai negatif di detail)
            // - ADJUST => ini dianggap delta (boleh + / -), user masukkan bisa dengan tanda + / -
            $qtyInput = trim($listQtyInput[$i] ?? '0');

            if ($idProduk <= 0) continue;
            if ($qtyInput === '' || !is_numeric(str_replace(['+','-'], '', $qtyInput))) continue;

            $qtyInput = (int)$qtyInput;

            // Normalisasi sesuai tipe transaksi
            if ($tipeTransaksi === 'IN') {
                if ($qtyInput <= 0) continue; // abaikan baris kosong / nol
                $qtyChange = $qtyInput;       // masuk = positif
            } elseif ($tipeTransaksi === 'OUT') {
                if ($qtyInput <= 0) continue;
                $qtyChange = -$qtyInput;      // keluar = negatif
            } else { // ADJUST
                // Di ADJUST, user boleh isi +5 atau -3; kalau user isi 5 tanpa tanda, anggap +5
                $qtyChange = (int)$qtyInput;
            }

            // (C3a) Pastikan baris inventory ada. Jika tidak ada → insert quantity=0
            $sqlCheckInv = "
              SELECT quantity FROM inventory 
              WHERE location_id=$idLokasi AND product_id=$idProduk LIMIT 1
            ";
            $resInv = mysqli_query($connection, $sqlCheckInv) or throw new Exception(mysqli_error($connection));

            if ($rowInv = mysqli_fetch_assoc($resInv)) {
                $qtyBefore = (int)$rowInv['quantity'];
            } else {
                mysqli_query($connection, "
                    INSERT INTO inventory(location_id, product_id, quantity)
                    VALUES ($idLokasi, $idProduk, 0)
                ") or throw new Exception(mysqli_error($connection));
                $qtyBefore = 0;
            }

            // (C3b) Validasi stok cukup untuk OUT (tidak boleh minus)
            if ($tipeTransaksi === 'OUT' && ($qtyBefore + $qtyChange) < 0) {
                throw new Exception("Stok tidak cukup untuk produk ID $idProduk (stok: $qtyBefore, minta: ".abs($qtyChange).")");
            }

            // (C3c) Hitung after & update inventory
            $qtyAfter = $qtyBefore + $qtyChange;
            mysqli_query($connection, "
                UPDATE inventory SET quantity=$qtyAfter
                WHERE location_id=$idLokasi AND product_id=$idProduk
            ") or throw new Exception(mysqli_error($connection));

            // (C3d) Simpan detail transaksi
            $sqlDet = "
              INSERT INTO transaction_details
              (transaction_id, product_id, location_id, quantity, quantity_before, quantity_after)
              VALUES ($idTransaksiBaru, $idProduk, $idLokasi, $qtyChange, $qtyBefore, $qtyAfter)
            ";
            mysqli_query($connection, $sqlDet) or throw new Exception(mysqli_error($connection));
        }

        // (C4) Commit
        mysqli_commit($connection);
        header("Location: transaksi.php?msg=add");
        exit;

    } catch (Exception $e) {
        mysqli_rollback($connection);
        die("Gagal menyimpan transaksi: " . htmlspecialchars($e->getMessage()));
    }
}
?>
<html lang="id">
<head>
    <meta charset="utf-8" />
    <title>Tambah Transaksi Stok</title>
    <link href="css/styles.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/tom-select/dist/css/tom-select.bootstrap5.min.css" rel="stylesheet" />
</head>
<body class="sb-nav-fixed">
<?php include "include/navbar.php"; ?>
<div id="layoutSidenav">
<?php include "include/menu.php"; ?>
<div id="layoutSidenav_content">
<main class="container-fluid px-4">
    <h1 class="mt-4">Tambah Transaksi</h1>
    <ol class="breadcrumb mb-4"><li class="breadcrumb-item active">IN / OUT / ADJUST</li></ol>

    <div class="mb-3"><a href="transaksi.php" class="btn btn-secondary"><i class="fa fa-arrow-left"></i> Kembali</a></div>

    <!-- ==================== FORM TRANSAKSI ==================== -->
    <div class="card mb-4">
        <div class="card-header bg-primary text-white">Form Transaksi Stok</div>
        <div class="card-body">
            <form method="POST" action="">
                <div class="row g-3">
                    <!-- Tipe Transaksi -->
                    <div class="col-md-3">
                        <label class="form-label">Tipe</label>
                        <select name="type" id="typeSelect" class="form-select" required>
                            <option value="IN">IN (Barang Masuk)</option>
                            <option value="OUT">OUT (Barang Keluar)</option>
                            <option value="ADJUST">ADJUST (Penyesuaian)</option>
                        </select>
                    </div>

                    <!-- Lokasi -->
                    <div class="col-md-4">
                        <label class="form-label">Lokasi</label>
                        <select name="location_id" id="lokasiSelect" class="form-select" required>
                            <option value="">-- Pilih Lokasi --</option>
                            <?php while($l=mysqli_fetch_assoc($resultLokasi)): ?>
                                <option value="<?= $l['location_id'] ?>"><?= htmlspecialchars($l['namalokasi']) ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>

                    <!-- Tanggal -->
                    <div class="col-md-3">
                        <label class="form-label">Tanggal</label>
                        <input type="datetime-local" name="transaction_date" class="form-control"
                               value="<?= date('Y-m-d\TH:i') ?>" required>
                    </div>

                    <!-- Catatan -->
                    <div class="col-md-12">
                        <label class="form-label">Catatan</label>
                        <input type="text" name="note" class="form-control" placeholder="Catatan (opsional)">
                    </div>
                </div>

                <!-- ====== KHUSUS TIPE IN: supplier + invoice ====== -->
                <div id="blokSupplier" class="row g-3 mt-3">
                    <div class="col-md-6">
                        <label class="form-label">Supplier (khusus IN)</label>
                        <select name="supplier_id" id="supplierSelect" class="form-select">
                            <option value="">-- Pilih Supplier --</option>
                            <?php while($s=mysqli_fetch_assoc($resultSupplier)): ?>
                                <option value="<?= $s['supplier_id'] ?>"><?= htmlspecialchars($s['namasupplier']) ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">No. Invoice (opsional)</label>
                        <input type="text" name="invoice" class="form-control" placeholder="Nomor invoice">
                    </div>
                </div>

                <hr>
                <h5>Detail Barang</h5>
                <p class="text-muted small mb-2">
                    IN: isi jumlah masuk (positif).&nbsp;
                    OUT: isi jumlah keluar (positif).&nbsp;
                    ADJUST: isi selisih (boleh + / -).
                </p>

                <!-- ====== TABEL DINAMIS DETAIL ====== -->
                <div id="detailContainer">
                    <div class="row detail-row mb-2">
                        <div class="col-md-7">
                            <select name="product_id[]" class="form-select tomselect-produk" required>
                                <option value="">-- Pilih Produk --</option>
                                <?php while($p=mysqli_fetch_assoc($resultProduk)): ?>
                                    <option value="<?= $p['product_id'] ?>"><?= htmlspecialchars($p['brand_name'].' '.$p['model_name']) ?></option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <input type="number" name="qty[]" class="form-control" placeholder="Qty" required>
                        </div>
                        <div class="col-md-2">
                            <button type="button" class="btn btn-danger removeRow">Hapus</button>
                        </div>
                    </div>
                </div>
                <button type="button" id="addRow" class="btn btn-sm btn-secondary mt-2">+ Tambah Baris</button>

                <div class="mt-4">
                    <button type="submit" name="btnSimpan" class="btn btn-success">Simpan Transaksi</button>
                </div>
            </form>
        </div>
    </div>
</main>
   <?php include "include/footer.php"; ?>

</div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/tom-select/dist/js/tom-select.complete.min.js"></script>
<script>
(function(){
  // ======================================================
  // CEGAH DOUBLE-BIND jika script ini kebetulan ter-load 2x
  // ======================================================
  if (window.__txAddBound) return; 
  window.__txAddBound = true;

  // ======================================================
  // (A) SIMPAN OPTION PRODUK MENTAH (sebelum TomSelect jalan)
  // ======================================================
  const firstSelect = document.querySelector('.detail-row select.tomselect-produk');
  // Ambil innerHTML option murni
  const productOptionsHTML = firstSelect ? firstSelect.innerHTML : '<option value="">-- Pilih Produk --</option>';

  // ======================================================
  // (B) Inisialisasi TomSelect untuk semua select produk
  // ======================================================
  function initTomSelectProduk(context=document){
    context.querySelectorAll('select.tomselect-produk').forEach(sel=>{
      if(!sel.tomselect){
        new TomSelect(sel,{
          persist:false,
          maxOptions:1000,
          sortField:{field:'text',direction:'asc'},
          placeholder:'Pilih produk...'
        });
      }
    });
  }
  // Init awal untuk baris pertama
  initTomSelectProduk();

  // ======================================================
  // (C) TAMBAH BARIS BARU TANPA CLONE DOM YANG SUDAH DIWRAP TS
  // ======================================================
  const container = document.getElementById('detailContainer');
  const btnAdd    = document.getElementById('addRow');

  btnAdd.addEventListener('click', ()=>{
    const row = document.createElement('div');
    row.className = 'row detail-row mb-2';
    row.innerHTML = `
      <div class="col-md-7">
        <select name="product_id[]" class="form-select tomselect-produk" required>
          ${productOptionsHTML}
        </select>
      </div>
      <div class="col-md-3">
        <input type="number" name="qty[]" class="form-control" placeholder="Qty" required>
      </div>
      <div class="col-md-2">
        <button type="button" class="btn btn-danger removeRow">Hapus</button>
      </div>
    `;
    container.appendChild(row);
    initTomSelectProduk(row); // init hanya baris baru
  });

  // ======================================================
  // (D) HAPUS BARIS
  // ======================================================
  document.addEventListener('click', (e)=>{
    if(e.target.classList.contains('removeRow')){
      const rows = document.querySelectorAll('.detail-row');
      if(rows.length > 1){
        e.target.closest('.detail-row').remove();
      }
    }
  });

  // ======================================================
  // (E) TAMPILKAN/SEMBUNYIKAN BLOK SUPPLIER SESUAI TIPE
  // ======================================================
  const typeSelect   = document.getElementById('typeSelect');
  const blokSupplier = document.getElementById('blokSupplier');
  function toggleSupplier(){
    blokSupplier.style.display = (typeSelect.value === 'IN') ? '' : 'none';
  }
  typeSelect.addEventListener('change', toggleSupplier);
  toggleSupplier();
})();
</script>

</body>
</html>
