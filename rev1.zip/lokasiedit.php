<?php
// ======================================================
// FILE   : lokasiedit.php
// DESC   : Halaman untuk mengedit data lokasi peyimpanan
// ======================================================

include_once "include/config.php";
include_once "include/guard.php";

// ---------- Ambil data berdasarkan ID ----------
$idlokasi = $_GET['id'];
$queryGetData = "SELECT * FROM location WHERE location_id=$idlokasi";
$resultData   = mysqli_query($connection, $queryGetData);
$dataLocation = mysqli_fetch_assoc($resultData);

// ======================================================
// (A) PROSES UPDATE DATA SAAT FORM DIKIRIM
// ======================================================
if (isset($_POST['Edit'])) {
    $namalokasi = mysqli_real_escape_string($connection, $_POST['namalokasi']);
    $alamat       = mysqli_real_escape_string($connection, $_POST['alamat']);
    $status       = $_POST['status'];

    $queryUpdateLocation = "
        UPDATE location 
        SET namalokasi='$namalokasi', alamat='$alamat', status=$status
        WHERE location_id=$idlokasi";
    mysqli_query($connection, $queryUpdateLocation);

    header("location:lokasi.php?msg=edit");
    exit;
}
?>

<!DOCTYPE html> 
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>Edit Lokasi Penyimpanan</title>
    <link href="css/styles.css" rel="stylesheet" />
</head>
<body class="sb-nav-fixed">
<?php include "include/navbar.php"; ?>
<div id="layoutSidenav">
    <?php include "include/menu.php"; ?>
    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid px-4">
                <h1 class="mt-4">Edit Lokasi Penyimpanan</h1>
                <form method="post">
                  <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label">Nama Lokasi</label>
                                    <input name="namalokasi" type="text" class="form-control" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Alamat</label>
                                    <input name="alamat" type="text" class="form-control">
                                </div>
                            </div>
                    <div class="mt-3">
                        <button class="btn btn-primary" name="Edit">Simpan Perubahan</button>
                        <a href="lokasi.php" class="btn btn-secondary">Batal</a>
                    </div>
                </form>
            </div>
        </main>
           <?php include "include/footer.php"; ?>

    </div>
</div>
</body>
</html>
